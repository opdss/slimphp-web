(function ($) {
    // Code
})(jQuery);
